# 라이브러리(jdk, javafx, spring 등) 제외
-libraryjars build/libs/*.jar

# 난독화 대상 패키지
-keep public class com.example.** {
    public *;
}

# main 클래스 유지
-keepclassmembers class com.example.AppLauncher {
    public static void main(java.lang.String[]);
}

-keep public class com.example.Main {
    public static void main(java.lang.String[]);
}

-dontwarn
-dontoptimize
-dontobfuscate
-keepclasseswithmembers public class * { public static void main(java.lang.String[]); }