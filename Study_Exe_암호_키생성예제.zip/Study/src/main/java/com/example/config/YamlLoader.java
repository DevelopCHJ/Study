package com.example.config;


import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;
import java.io.InputStream;
import java.util.Map;

//@Component
//public class YamlLoader {
//
//    private Map<String, Object> yamlMap;
//
//    public YamlLoader() {
//        try (InputStream in = getClass().getClassLoader().getResourceAsStream("config.yml")) {
//            if (in == null) throw new RuntimeException("YAML file not found: config.yml");
//            Yaml yaml = new Yaml();
//            yamlMap = yaml.load(in);
//        } catch (Exception e) {
//            throw new RuntimeException("Failed to load YAML", e);
//        }
//    }
//
//    public Map<String, Object> getYamlMap() {
//        return yamlMap;
//    }
//
//    @SuppressWarnings("unchecked")
//    public Map<String, Object> getNestedMap(String key) {
//        Object value = yamlMap.get(key);
//        if (value instanceof Map) return (Map<String, Object>) value;
//        throw new RuntimeException(key + " is not a nested map in YAML");
//    }
//}